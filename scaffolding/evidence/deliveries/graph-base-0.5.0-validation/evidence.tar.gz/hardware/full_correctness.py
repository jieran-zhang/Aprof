import fcntl, hashlib, importlib.util, json, os, pathlib, runpy, subprocess, sys, time
root=pathlib.Path(__file__).resolve().parent
prepared=pathlib.Path(json.loads((root/'prepare-cold-cpu.json').read_text())['output_dir'])
sys.path.insert(0,str(root/'exp-baseline/scripts'));import verify_result
lock=pathlib.Path('/tmp/aprof-device-locks/device-0.lock');lock.parent.mkdir(exist_ok=True)
results=[];started=time.monotonic()
with lock.open('a+') as held:
 fcntl.flock(held,fcntl.LOCK_EX)
 for role,project_name in [('baseline','exp-baseline'),('candidate','exp-twin')]:
  project=root/project_name;role_start=time.monotonic()
  for case in range(1,21):
   path=root/f'correctness-{role}'/f'case-{case:02d}';path.mkdir(parents=True,exist_ok=False)
   m=json.loads((prepared/f'case_{case:02d}/metadata.json').read_text());m['output']=str(path/'output.bin');metadata=path/'metadata.json';metadata.write_text(json.dumps(m,indent=2)+'\n')
   argv=[str(project/'build/exp')]
   for name in ('numel','dtype','input','output','base','scale','shift'):argv+=['--'+name,str(m[name])]
   argv+=['--device','0'];env=dict(os.environ)
   for key in ('APROF_TIMING','APROF_TIMING_INTERACTIVE','APROF_CAPTURE_REPLAY','APROF_SAMPLES'):env.pop(key,None)
   with (path/'execution.txt').open('w') as log:subprocess.run(argv,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
   sys.argv=['verify_cached.py','--metadata',str(metadata),'--reference',str(prepared/f'case_{case:02d}/reference.bin'),'--project',str(project)];runpy.run_path(str(root/'verify_cached.py'),run_name='__main__')
   cached=json.loads((path/'cached_result.json').read_text())
   sys.argv=['verify_result.py','--metadata',str(metadata)];verify_result.main()
   original=json.loads((path/'result.json').read_text())
   for key in ('mere','mare','threshold','special_values_match','passed'):assert cached[key]==original[key],(case,key)
   results.append({'role':role,'case_id':case,'passed':True,'cached_oracle_matches_original_verifier':True,'command':argv})
  print(json.dumps({'role':role,'elapsed_seconds':time.monotonic()-role_start}),flush=True)
(root/'full-correctness.json').write_text(json.dumps({'elapsed_seconds':time.monotonic()-started,'passed':len(results),'total':40,'cached_reference_matches_original':True,'results':results},indent=2)+'\n')
