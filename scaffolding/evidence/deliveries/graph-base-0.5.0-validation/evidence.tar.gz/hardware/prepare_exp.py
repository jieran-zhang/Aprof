import argparse, importlib.util, json, pathlib, sys
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--project',required=True);a=p.parse_args()
project=pathlib.Path(a.project).resolve();out=pathlib.Path(a.output).resolve();sys.path.insert(0,str(project/'scripts'))
import gen_data, verify_result
for case in range(1,21):
 sys.argv=['gen_data.py','--case',str(case),'--output',str(out)];gen_data.main()
 d=out/f'case_{case:02d}';m=json.loads((d/'metadata.json').read_text())
 with open(m['input'],'rb') as src,(d/'reference.bin').open('wb') as dst:
  for start in range(0,m['numel'],1_000_000):
   x=verify_result.load_chunk(src,m['dtype'],min(1_000_000,m['numel']-start))
   temp=x.astype(np.float32)*np.float32(m['scale'])+np.float32(m['shift'])
   if m['base']>0:temp=temp*np.log(np.float32(m['base']))
   with np.errstate(all='ignore'):ref=verify_result.quantize(np.exp(temp).astype(np.float32),m['dtype'])
   dst.write(ref.astype(np.float32).tobytes())
