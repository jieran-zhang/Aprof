import argparse,json,pathlib,sys
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--metadata',required=True);p.add_argument('--reference',required=True);p.add_argument('--project',required=True);a=p.parse_args()
sys.path.insert(0,str(pathlib.Path(a.project)/'scripts'));import verify_result
mp=pathlib.Path(a.metadata);m=json.loads(mp.read_text());n=m['numel'];dt=m['dtype']
assert pathlib.Path(m['output']).stat().st_size==n*(4 if dt=='float32' else 2)
assert pathlib.Path(a.reference).stat().st_size==n*4
rel_sum=0.;rel_max=0.;finite_count=0;special_ok=True
with open(m['output'],'rb') as actual_file,open(a.reference,'rb') as expected_file:
 for start in range(0,n,1_000_000):
  count=min(1_000_000,n-start);actual=verify_result.load_chunk(actual_file,dt,count);expected=np.fromfile(expected_file,dtype=np.float32,count=count)
  special_ok &= bool(np.array_equal(np.isnan(actual),np.isnan(expected)))
  special_ok &= bool(np.array_equal(np.isposinf(actual),np.isposinf(expected)))
  special_ok &= bool(np.array_equal(np.isneginf(actual),np.isneginf(expected)))
  finite=np.isfinite(actual)&np.isfinite(expected)
  if finite.any():
   rel=np.abs(actual[finite]-expected[finite])/(np.abs(expected[finite])+1e-7)
   rel_sum+=float(rel.sum(dtype=np.float64));rel_max=max(rel_max,float(rel.max()));finite_count+=int(finite.sum())
threshold={'float16':2**-10,'bfloat16':2**-7,'float32':2**-13}[dt]
mere=rel_sum/max(1,finite_count);passed=bool(special_ok and mere<threshold and rel_max<10*threshold)
result={'case_id':m['case_id'],'mere':mere,'mare':rel_max,'threshold':threshold,'special_values_match':special_ok,'passed':passed}
(mp.parent/'cached_result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if not passed:raise SystemExit(1)
