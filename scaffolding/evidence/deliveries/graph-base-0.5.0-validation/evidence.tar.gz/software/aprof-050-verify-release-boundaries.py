from pathlib import Path
import importlib.util,json,subprocess,hashlib
repo=Path('/mnt/tidalfs-hwwh01/dataset/dots_infra/workspace/jieran/APROF/aprof-restructured')
r=repo/'skill-libs/graph-base/0.5.0';old=r.parent/'0.4.2';copy=Path('/tmp/aprof-050-final-fl0t5dqs/graph-base/0.5.0')
s=importlib.util.spec_from_file_location('release050',r/'tools/release.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
release_checks={}
for v in ('0.4.1','0.4.2','0.5.0'):
    value=m.verify(r.parent/v);release_checks[v]={'files':len(value['files']),'runtime':value['runtime_version']}
unchanged={}
for name in ('runtime','schemas','skillgraph/versions'):
    a={str(p.relative_to(old/name)):m.sha(p) for p in (old/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.egg-info' not in str(p)}
    b={str(p.relative_to(r/name)):m.sha(p) for p in (r/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.egg-info' not in str(p)}
    assert a==b,name;unchanged[name]=len(a)
assert (copy/'release.json').read_bytes()==(r/'release.json').read_bytes()
for v in ('0.4.1','0.4.2'):
    output=subprocess.check_output(['git','diff','HEAD','--','skill-libs/graph-base/'+v],cwd=repo);assert not output
x=json.loads(Path('/tmp/aprof-050-standalone-bcanjj_7/gate.stdout.txt').read_text())['result']['outcomes'][0]
y=json.loads(Path('/tmp/aprof-050-standalone-bcanjj_7/finalize.stdout.txt').read_text())['result']['episodes'][0]['outcome']
assert x['decision_hash']==y['decision_hash'] and x['eligible'] and y['eligible']
result={'release_checks':release_checks,'unchanged_from_0_4_2':unchanged,'installed_copy_seal_identical':True,'historical_release_git_diff_empty':True,'synthetic_gate_finalize_decision_hash':x['decision_hash'],'synthetic_only':True}
Path('/tmp/aprof-050-boundaries.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
