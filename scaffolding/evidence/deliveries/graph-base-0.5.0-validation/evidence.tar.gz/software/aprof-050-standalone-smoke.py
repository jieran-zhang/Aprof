import os,json,subprocess,tempfile,shutil,time
from pathlib import Path
r=Path('/tmp/aprof-050-final-fl0t5dqs/graph-base/0.5.0')
p=Path(tempfile.mkdtemp(prefix='aprof-050-standalone-'))
Path('/tmp/aprof-050-smoke-path').write_text(str(p))
old=Path('/tmp/aprof-042-cli-smoke-xyeforn4')
for f in ('request.json','context.json'): shutil.copy2(old/f,p/f)
e=dict(os.environ);e.pop('PYTHONPATH',None);e.pop('APROF_SKILL_LIB',None);e['PYTHONDONTWRITEBYTECODE']='1'
python=str(r/'.runtime-env/bin/python');ctl=str(r/'tools/aprofctl');graph=str(r/'skillgraph/versions/v0001')
commands=[('release',[python,str(r/'tools/release.py')]),('graph-v0001',[ctl,'graph','validate','--graph',graph]),('graph-v0002',[ctl,'graph','validate','--graph',str(r/'skillgraph/versions/v0002')]),('contract',[ctl,'contract','validate','--kind','gate_request','--input',str(p/'request.json')]),('route',[ctl,'graph','route','--graph',graph,'--context',str(p/'context.json')])]
setup='''from pathlib import Path
from aprof_runtime.store import EpisodeStore
import sys
with EpisodeStore(Path(sys.argv[1])) as store:
    files=list(Path(sys.argv[2]).rglob('*'))
    count=0
    for file in files:
        if file.is_file():
            store.register_artifact(file)
            count+=1
print(count)
'''
commands.append(('import-synthetic-cas',[python,'-c',setup,str(p/'synthetic.sqlite'),str(old/'synthetic.sqlite.objects')]))
commands += [('gate',[ctl,'candidate','gate','--request',str(p/'request.json'),'--store',str(p/'synthetic.sqlite')]),('finalize',[ctl,'episode','finalize','--context',str(p/'context.json'),'--request',str(p/'request.json'),'--graph',graph,'--store',str(p/'synthetic.sqlite')]),('reopen-verify',[ctl,'episode','verify','--store',str(p/'synthetic.sqlite')])]
for tool in ('prepare_workload.py','device_paired_timing.py','profile_capture.py','normalize_profile.py'):
    commands.append((tool+'-help',[python,str(r/'skills/ascendc-aprof-profiling/scripts'/tool),'--help']))
commands.append(('select-a3',[python,str(r/'skills/ascendc-aprof-profiling/scripts/profile_capture.py'),'select','--backend','auto','--architecture','Ascend910C','--soc','9392']))
rows=[]
for name,cmd in commands:
    start=time.monotonic(); out=subprocess.run(cmd,cwd=p,env=e,capture_output=True,text=True)
    (p/(name+'.stdout.txt')).write_text(out.stdout);(p/(name+'.stderr.txt')).write_text(out.stderr)
    rows.append({'name':name,'command':cmd,'exit_code':out.returncode,'elapsed_seconds':time.monotonic()-start})
    if out.returncode:
        print(name,'FAILED',out.stderr[-1500:]);break
(p/'receipt.json').write_text(json.dumps({'release':str(r),'synthetic_only':True,'checks':rows},indent=2)+'\n')
print(p);print([(i['name'],i['exit_code']) for i in rows]);assert len(rows)==len(commands) and all(i['exit_code']==0 for i in rows)
gate=json.loads((p/'gate.stdout.txt').read_text());final=json.loads((p/'finalize.stdout.txt').read_text());print('gate result keys',gate.keys(),'finalize keys',final.keys())
