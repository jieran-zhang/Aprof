#pragma once
#include <cstdint>
#include <algorithm>
#include <stdexcept>
#include <vector>
enum GroupNormDType:uint32_t{GN_FLOAT16=0,GN_FLOAT32=1,GN_BFLOAT16=2};
struct GroupNormTilingData{uint64_t totalLength,spatial,groupElements,groupCount,groupsPerBlock;uint32_t N,C,numGroups,channelsPerGroup,blockNum,dtype,tileElements;float epsilon,invGroupElements;};
inline uint64_t GnGcd(uint64_t a,uint64_t b){while(b){uint64_t r=a%b;a=b;b=r;}return a;}
inline void ConfigureGroupNormSchedule(GroupNormTilingData&t,int64_t visibleCores){
 if(t.groupCount==0||t.groupElements==0)throw std::invalid_argument("empty group norm workload");
 const uint64_t cores=static_cast<uint64_t>(std::max<int64_t>(1,std::min<int64_t>(visibleCores,48)));
 const uint64_t item=t.dtype==GN_FLOAT32?4:2;
 // Whole groups remain indivisible. Pack adjacent groups so each core's
 // output interval starts on a64-byte boundary; only the final core tails.
 const uint64_t alignment=64/GnGcd((t.groupElements%64)*item,64);
 const uint64_t average=(t.groupCount+cores-1)/cores;
 t.groupsPerBlock=((average+alignment-1)/alignment)*alignment;
 t.blockNum=static_cast<uint32_t>((t.groupCount+t.groupsPerBlock-1)/t.groupsPerBlock);
}
inline GroupNormTilingData ComputeGroupNormTiling(const std::vector<uint64_t>&s,uint32_t groups,uint32_t dtype,float eps){
 if(s.size()<2||s.size()>8||groups==0||s[1]%groups||!(eps>0))throw std::invalid_argument("invalid group norm shape/attrs");GroupNormTilingData t{};t.N=s[0];t.C=s[1];t.numGroups=groups;t.channelsPerGroup=t.C/groups;t.spatial=1;for(size_t i=2;i<s.size();++i)t.spatial*=s[i];t.groupElements=static_cast<uint64_t>(t.channelsPerGroup)*t.spatial;t.groupCount=static_cast<uint64_t>(t.N)*groups;t.totalLength=t.groupCount*t.groupElements;t.dtype=dtype;t.epsilon=eps;t.invGroupElements=1.0f/static_cast<float>(t.groupElements);t.blockNum=static_cast<uint32_t>(t.groupCount<32?t.groupCount:32);t.tileElements=4096;ConfigureGroupNormSchedule(t,32);return t;}
