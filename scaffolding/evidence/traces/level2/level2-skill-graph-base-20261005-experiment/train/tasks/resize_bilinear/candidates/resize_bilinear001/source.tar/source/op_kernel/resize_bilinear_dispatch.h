#pragma once
#include "resize_bilinear_tiling.h"
inline uint64_t SelectTilingKey(const ResizeBilinearTilingData &t) {
 const uint64_t item=t.dtype==RESIZE_FP32?4:2;
 if((t.outW*item)%64)return 0;
 return t.dtype==RESIZE_FP32?1:2;
}
