#pragma once
#include "unsorted_segment_sum_tiling.h"
inline uint64_t SelectTilingKey(const UssTiling &t) { return t.inner>=128?1:0; }
