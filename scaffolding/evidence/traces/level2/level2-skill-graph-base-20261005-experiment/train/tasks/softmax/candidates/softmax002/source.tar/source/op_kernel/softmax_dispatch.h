#pragma once
#include <cstdint>
#include "softmax_dtype.h"
inline uint64_t SoftmaxRequiredUbBytes(uint64_t reduce, uint32_t dtype) {
    const uint64_t item = dtype == SOFTMAX_FLOAT32 ? 4 : 2;
    const uint64_t align = dtype == SOFTMAX_FLOAT16 ? 64 : (dtype == SOFTMAX_BFLOAT16 ? 16 : 8);
    const uint64_t r = ((reduce + align - 1) / align) * align;
    const uint64_t mask = dtype == SOFTMAX_FLOAT16 ? (((r + 7) / 8 + 255) / 256) * 256 : 0;
    uint64_t raw = r * item + 16384;
    if (dtype == SOFTMAX_FLOAT16 && raw < 4 * r) raw = 4 * r;
    return raw + r * (8 + item) + 4096 + 32 + mask;
}
inline uint64_t SelectSoftmaxTilingKey(uint64_t inner, uint64_t reduce, uint32_t dtype) {
    const uint64_t item = dtype == SOFTMAX_FLOAT32 ? 4 : 2;
    if (inner == 1 && reduce >= 1 && reduce <= 128) return 22;
    if (SoftmaxRequiredUbBytes(reduce, dtype) <= 196352) {
        if (inner == 1 && reduce > 128) return 20;
        if (inner > 1 && inner >= 32 / item) return 21;
    }
    return 0;
}
