#pragma once
#include <cstdint>
enum SoftmaxDType : uint32_t {
    SOFTMAX_FLOAT16 = 0,
    SOFTMAX_FLOAT32 = 1,
    SOFTMAX_BFLOAT16 = 2,
};
