#pragma once
#include "maximum_tiling.h"
// Same semantic predicates as dispatch_plan: no case, value, seed or timing input.
inline uint64_t SelectMaximumTilingKey(const std::vector<uint64_t>& x1,
                                     const std::vector<uint64_t>& x2, uint32_t dtype) {
    if (x1 == x2) return dtype == MAX_INT64 ? 2ULL : 1ULL;
    const size_t rank = std::max(x1.size(), x2.size());
    std::vector<uint64_t> a(rank, 1), b(rank, 1);
    std::copy(x1.begin(), x1.end(), a.begin() + rank - x1.size());
    std::copy(x2.begin(), x2.end(), b.begin() + rank - x2.size());
    bool rhsLastAxis = b.back() == std::max(a.back(), b.back());
    for (size_t d = 0; d < rank; ++d) {
        rhsLastAxis = rhsLastAxis && a[d] == std::max(a[d], b[d]);
        if (d + 1 < rank) rhsLastAxis = rhsLastAxis && b[d] == 1;
    }
    return rhsLastAxis && dtype != MAX_INT64 ? 3ULL : 0ULL;
}
