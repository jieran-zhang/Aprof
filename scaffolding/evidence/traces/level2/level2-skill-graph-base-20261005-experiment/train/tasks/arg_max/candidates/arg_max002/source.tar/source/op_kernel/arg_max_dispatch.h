#pragma once
#include "arg_max_tiling.h"
inline uint64_t SelectArgMaxTilingKey(const ArgMaxTilingData& t, int64_t availableCores) {
    if (t.dtype == ARG_MAX_INT32 || t.dtype == ARG_MAX_INT64) return 0;
    // This plan is bound to a probed 48-AIV profile. Other allocations retain
    // the generic implementation and require a fresh architecture plan.
    if (availableCores != 48) return 0;
    if (t.innerLength > 1) return 32;
    return t.outputLength < 48 ? 31 : 30;
}
