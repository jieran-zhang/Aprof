#pragma once
#include "scatter_tiling.h"
inline uint64_t SelectTilingKey(const ScatterTilingData &t) {
 const uint64_t item=(t.dataType==SCATTER_FLOAT16||t.dataType==SCATTER_BFLOAT16)?2:(t.dataType==SCATTER_INT64?8:4);
 bool same=true;
 for(uint32_t axis=0;axis<t.rank;++axis){const uint64_t d=axis==0?t.dataLength/t.dataStride[0]:t.dataStride[axis-1]/t.dataStride[axis];if(axis!=t.dim&&d!=t.updateShape[axis])same=false;}
 const uint64_t last=t.rank==1?t.dataLength:t.dataStride[t.rank-2];
 const bool row=t.rank>1&&t.dim+1==t.rank&&same&&(last*item)%64==0;
 const bool half=t.dataType==SCATTER_FLOAT16&&(t.reduce==SCATTER_ADD||t.reduce==SCATTER_MULTIPLY);
 if(row)return half?11:(t.dataType==SCATTER_FLOAT16?12:1);
 return half?10:0;
}
